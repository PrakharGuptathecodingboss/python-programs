import math
#input section
l1 = eval(input('Enter the length of floor: '))
b1 = eval(input('Enter the breadth of floor: '))
l2 = eval(input('Enter the length of single tile: '))
b2 = eval(input('Enter the breadth of single tile: '))

#logic section
number = math.ceil((l1*b1)/(l2*b2))

#display section
print(f'Number of tiles are {number}')
