l=list(map(int,input().split()))
print(max(list(map(l.count,l))))
