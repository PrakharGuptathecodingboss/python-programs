'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
n=int(input())
s=input()
ls=list(s)
c=0
for i in range(len(ls)):
    for j in range(i+1,len(ls)-1):
        l=len(ls[i])
        if ls[i][l]==ls[j][0]:
            c+=1
            break
if c==len(s):
    print('True')
else:
    print('False')