l=eval(input())
flag=0
for i in range(len(l)-1):
    if sum(l[:i])==sum(l[i:]):
        flag=1
        break
if flag:
    print("List can be balanced")
else:
    print("List cannot be balanced")