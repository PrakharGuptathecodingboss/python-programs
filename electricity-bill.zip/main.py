'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
unit=int(input('Enter the units consumed: '))
if unit>=50:
    amount=unit*0.50
elif unit>50 and unit<=150:
    amount=50*.50+(unit-50)*.75
elif unit>150 and unit<=250:
    amount=50*.50+100*.75+(unit-150)*1.25
else:
    amount=50*.50+100*.75+100*1.25+(unit-250)*1.50
final=amount+0.2*amount
print('Total amount of the bill is',final)
    