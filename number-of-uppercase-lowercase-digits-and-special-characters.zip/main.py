s=input()
c1=0
c2=0
c3=0
c4=0
for i in s:
    if ord(i)>=65 and ord(i)<=90:
        c1+=1
    if ord(i)>=97 and ord(i)<=122:
        c2+=1
    if ord(i)>=48 and ord(i)<=57:
        c3+=1
    else:
        c4+=1
print(f'No. of uppercase alphabets are :{c1}')
print(f'No. of lowercase alphabets are :{c2}')
print(f'No. of digits are :{c3}')
print(f'No. of special characters are :{c4}')