ls = [1,2,0,8,5]
ls.sort()
print(ls)
ls.sort(reverse = True)
x = ls.index(0)
print(ls)
print(x)

