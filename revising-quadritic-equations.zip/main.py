import math as m
a,b,c=map(int,input().split())
ls=[]
d=(b*b)-(4*a*c)
r1=int(-1*b + m.sqrt(b**2 - 4*a*c)/2*a)
r2=int(-1*b - m.sqrt(b**2 - 4*a*c)/2*a)
ls.append(r1)
ls.append(r2)
if d>0:
	print("Real and Distinct")
	ls.sort
	print(*ls)
elif d==0:
	print("Real and Equal")
	print(*ls)
else:
	print("Imaginary")

	