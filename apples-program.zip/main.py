n=int(input())
if n%2==0 or n%3==0 or n%4==0 or n%5==0 or n%6==0:
    print('Minimum number of apples the man will be having=' ,n-1)
else:
    print('Minimum number of apples the man will be having=',n)