import math 
r=eval(input('Enter the radius of circle'))
area=math.pi*r**2
print(f'Area of cirle {area:.2f}')

