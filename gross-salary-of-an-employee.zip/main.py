'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
bs = float(input('Enter the basic salary of employee: '))
if bs<=10000:
    da=0.8*bs
    hra=0.2*bs
elif bs>10000 and bs<=20000:
    da=0.9*bs
    hra=2.5*bs
else:
    da=9.5*bs
    hra=0.3*bs  
gs=bs+da+hra
print('Gross salary of the employee is=',gs)