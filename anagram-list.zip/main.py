ls1=list(input().split())
ls2=list(input().split())
c=0
for i in ls1:
    for j in ls2:
        a=''.join(sorted(i))
        b=''.join(sorted(j))
        if a==b:
            c+=1
print(c)