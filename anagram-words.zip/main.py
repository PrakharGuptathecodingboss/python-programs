s1=input().lower()
s2=input().lower()
f=0
for i in s1:
    if i not in s2:
        f=1
        break
if f==0:
    print("Anagram Words")
else:
    print("NOT")