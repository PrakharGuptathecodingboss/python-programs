n=int(input())
d=(n//2)+1
for i in range(1,n+1):
    for j in range(1,n+1):
        if j==1 and i<=d:
            print("*",end='')
        if j==n and i>=d:
            print("*",end='')
        if j==d:
            print("*",end='')
        if j>=d and i==1:
            print("*",end='')
        if j<=d and i==n:
            print("*",end='')
        else:
            print(" ")