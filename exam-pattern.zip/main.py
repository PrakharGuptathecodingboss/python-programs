'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
rows=int(input())
for i in range(1,rows+1):
    for j in range(rows-i+1):
        print('*',end='')
    for j in range(i-1):
        print(' ',end='')
    for j in range(i-1):
        print(' ',end='')
    for j in range(rows-i+1):
        print('*',end='')
    print()
