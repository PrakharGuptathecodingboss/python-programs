s=0
l=[]
ls=map(int,input().split())
for i in ls:
    s+=i
    if(s<0):
        break
    else:
        l.append(i)
for i in l:
    print(i)