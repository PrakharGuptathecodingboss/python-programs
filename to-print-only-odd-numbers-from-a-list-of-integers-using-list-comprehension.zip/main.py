n=list(map(int,input().split()))
t=[i for i in n if i%2!=0]
print(t)