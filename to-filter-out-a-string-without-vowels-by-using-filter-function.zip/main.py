def vowel(s):
    return s not in 'AEIOUaeiou'
st=input()
ls=list(st)
out=filter(vowel,ls)
print(''.join(out))
