s=input()
c1=0
c2=0
c3=0
c4=0
c5=0
for i in s:
    if i.isupper():
        c1+=1
    elif i.islower():
        c2+=1
    elif i.isdigit():
        c3+=1
    elif i.isspace():
        c4+=1
    else:
        c5+=1
print(f'No. of uppercase alphabets are :{c1}')
print(f'No. of lowercase alphabets are :{c2}')
print(f'No. of digits are :{c3}')
print(f'No. of spaces are :{c4}')
print(f'No. of special characters are :{c5}')