over=int(input('Enter the number of overs: '))
max_runs=6*5*(over-1)+6*6+(over-1)*3
print(f'Maximum runs in {over} will be: {max_runs}')