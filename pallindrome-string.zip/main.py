
a = input("Enter the value of number :")
b = a[ : :-1]
print(b)
if a==b:
    print("Palindrome number")
else:
    print("Not a palindrome number")

