head=int(input('Enter the number of heads: '))
feet=int(input('Enter the number of tails: '))
y=(feet-2*head)//2
x=head-y
print('Number of chickens=',x)
print('Number of goats=',y)