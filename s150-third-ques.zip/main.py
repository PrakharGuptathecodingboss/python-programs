n=int(input())
l=[]
for i in range(n):
    a=(input())
    b=int(a,2)
    l.append(b)
for i in l:
    print(i)
    