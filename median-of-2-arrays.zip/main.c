/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
  int n,m,pos,pos1,pos2,i;
  scanf("%d%d",&n,&m);
  int a[n],b[m];
  for(i=0;i<n;i++){
  scanf("%d",&a[i]);}
  for(i=0;i<m;i++){
  scanf("%d",&a[i]);}
  for(i=0;i<n;i++){
      if(n%2!=0){
          pos=(n+1)/2;
          printf("%d",a[pos]);}
      else{
         pos1=(n/2);
         pos2=(n/2)+1;
         printf("%d",(a[pos1]+a[pos2])/2);}
  for(i=0;i<m;i++){
      if(m%2!=0){
          pos=(m+1)/2;
          printf("%d",b[pos]);}
      else{
         pos1=(n/2);
         pos2=(n/2)+1;
         printf("%d",(b[pos1]+b[pos2])/2);}
      }
  }
   return 0;
}
