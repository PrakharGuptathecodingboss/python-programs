import math as m
radius=eval(input('Enter the radius of circle: '))
area=m.pi*radius*radius
print(f'Area of of circle= {area}')


