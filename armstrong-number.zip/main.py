n=int(input('Enter the number: '))
c=0
s=0
num=n
number=num
while n>0:
    c=c+1
    n=n//10
while num>0:
    r=num%10
    s+=r**c
    num=num//10
if s==number:
    print("Armstrong number")
else:
    print("Not an armstrong number")
    