'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
n=int(input('Enter the number: '))
num=n
rev=0
while n>0:
    r=n%10
    rev=rev*10+r
    n=n//10
if rev==num:
    print(num,"is a pallindrome number")
else:
    print(num,"is not a pallindrome number")

