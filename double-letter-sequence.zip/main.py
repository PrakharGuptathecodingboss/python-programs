s=input()
st=''
stt=''
l=[]
for i in s:
    if s!=' ':
        stt+=i
for i in stt:
    for j in stt:
        if ord(i)>=48 and ord(i)<=57 or ord(j)>=48 and ord(j)<=57:
            continue 
        st=i+j
        if len(st)==2:
            l.append(st)
            st=''
l.sort()
l=set(l)
print(*l,sep='\n')