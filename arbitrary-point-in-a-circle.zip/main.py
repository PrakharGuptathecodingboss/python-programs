x=int(input('Enter the x-coordinate of centre of circle: '))
y=int(input('Enter the y-coordinate of centre of circle: '))
r=int(input('Enter the radius of circle: '))
x1=int(input('Enter the x-coordinate of arbitary point of circle: '))
y1=int(input('Enter the y-coordinate of arbitary point of circle: '))
d=((x1-x)**2+(y1-y)**2)**.5
if d>r:
    print("Point is outside the circle")
elif d<r:
    print("Point is inside the circle")
else:
    print("Point is one the circle")
    