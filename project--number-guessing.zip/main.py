
import random
t=1
while t==1:
    d=0
    level=int(input('Enter the level: '))
    print(f'Choose number between 1 and {100*level}')
    attempt= level+2
    while attempt!=0:
        a= random.randint(1,100*level)
        b= int(input('Enter the number: '))
        if a==b:
            print('You have chosen the right number')
            d=1
            break
        else:
            c=abs(a-b)
            if a<b:
                if c<20:
                    print('Large')
                else:
                    print('Too large')
            else:
                if c<20:
                    print('Small')
                else:
                    print('Too small')
        attempt=attempt-1
        print(f'Remaining attempts :{attempt}')
    if d==1:
        print('You have won the game')
        print(f'correct answer was: {b}')
    else:
        print('You have lost')
    t=int(input('Do you want to play again? if yes then type if no then 0: '))

    

