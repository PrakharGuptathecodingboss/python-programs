'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#input section
amount = int(input('Enter the amount to be transacted: '))

#logic section
amount=amount-100
twok=amount//2000
amount=amount%2000
fiveh=amount//500
amount=amount%500
twoh=amount//200
amount=amount%200
oneh=amount//100+1
#display section
print(f'Number of 2000 notes {twok}')
print(f'Number of 500 notes {fiveh}')
print(f'Number of 200 notes {twoh}')
print(f'Number of 100 notes {oneh}')
