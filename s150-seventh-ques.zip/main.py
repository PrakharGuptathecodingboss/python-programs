n=int(input())
l=[]
for i in range(1,n+1):
    s=3*i+2
    if s%4==0:
        pass
    else:
        l.append(s)
for i in l:
    print(i)
print(sum(l))
