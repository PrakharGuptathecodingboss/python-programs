'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
a = float(input('Enter first side of triangle: '))
b = float(input('Enter second side of triangle: '))
c = float(input('Enter third side of triangle: '))
if a+b<c or b+c<a or c+a<b:
    print('Triangle is not possible')
else:
    print('Triangle is possible')

