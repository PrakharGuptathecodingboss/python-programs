'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
import random
x,y=map(int,input('Enter the range: ').split())
n=int(input('Enter the number: '))
b=0
a=random.randint(x,y)
while (x+y//2)==0:
    avg=x+y//2
    if a==avg:
        b+=1
        print('Congratulations,you guessed right')
        break
    elif a<avg:
        y=avg
        print('Your guess is too small')
    else:
        x=avg
        print('Your guess is too large')
