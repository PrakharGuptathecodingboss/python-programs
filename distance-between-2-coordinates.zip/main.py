'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#input section
x1 = eval(input('Enter the value of x1: '))
y1 = eval(input('Enter the value of y1: '))
x2 = eval(input('Enter the value of x2: '))
y2 = eval(input('Enter the value of y2: '))

#logic section
dis = ((x2-x1)**2+(y2-y1)**2)**.5

#display section
print(f'Distance between two coordinates is {dis:.2f}')
