from math import pi
r=eval(input('Enter the radius of circle'))
area=pi*r**2
print(f'Area of cirle {area:.2f}')


