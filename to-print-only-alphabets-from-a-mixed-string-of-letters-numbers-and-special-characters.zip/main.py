s=input()
m=[i for i in s if i.isalpha()]
print(''.join(m))