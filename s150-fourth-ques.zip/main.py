t=int(input())
s=0
for _ in range(t):
	n=int(input())
	l=list(map(int,input().split()))
	ls=list(map(int,input().split()))
for i in range(n):
	for j in range(i+1):
		s+=abs(l[i]-l[j])*max(ls[i],ls[j])
print(s)