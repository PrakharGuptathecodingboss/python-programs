def even(ls):
    return ls%2==0
ls=eval(input())
t=filter(even,ls)
print(list(t))