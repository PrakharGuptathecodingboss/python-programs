s=input()
dct={i:s.count(i) for i in s}
print(dct)