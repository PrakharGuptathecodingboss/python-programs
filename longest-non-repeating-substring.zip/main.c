/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n;
    scanf("%d",&n);
    char ch[n];
    scanf("%s",ch);
    int c=0,i;
    for(i=0;i<100;i++){
    if(ch[i]!=ch[i+1])
        c++;
        else
        continue;}
    printf("%d",c);
    return 0;
}
